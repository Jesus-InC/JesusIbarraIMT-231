echo "Bienvenido, por favor, ingrese su nombre"
read nombre
echo "Bienvenido, "$nombre", un gusto saludarte"
echo "Mostrando el contenido de la carpeta..."
tree
echo "Script finalizado con éxito."

